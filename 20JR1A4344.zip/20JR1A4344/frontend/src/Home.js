import React from 'react';


function Home() {
  return (
    <header>
      <nav>
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/schedule">Schedule</a></li>
          <li><a href="/stations">Stations</a></li>
          <li><a href="/about">About</a></li>
          <li><a href="/Register">Register</a></li>
          <li><a href="/login">Login</a></li>

        </ul>
      </nav>
      <li><a href="/login">Login</a></li>
    </header>
  );
}


export default Home;
